# Web NFC Demo (Next.js 13)

Minimal project Next 13 dengan tombol scan NFC.

## Cara jalanin di Termux / Android
```bash
npm install
npm run dev
```
- Buka **http://localhost:3000** di Chrome Android
- Klik tombol **Mulai Scan NFC** lalu tempel tag

Note: Web NFC hanya jalan di HTTPS atau localhost, dan hanya di Chrome Android terbaru.
